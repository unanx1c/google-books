package google.books.data;


import lombok.Data;


@Data
public class PublicBookshelfs {
    private String kind;
    private int totalItems;
}
