package google.books;

public enum BookOperation {
    SEARCH_FOR_BOOKS,
    RETRIEVE_VOLUME_BY_ID,
    FETCH_PUBLIC_BOOKSHELVES,
    FETCH_BOOKSHELF_BY_ID,
    GET_BOOKSHELF_VOLUMES;
}
